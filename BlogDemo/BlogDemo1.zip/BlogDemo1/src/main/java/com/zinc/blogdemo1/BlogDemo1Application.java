package com.zinc.blogdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogDemo1Application {

    public static void main(String[] args) {
        SpringApplication.run(BlogDemo1Application.class, args);
    }

}
