package com.zinc.blogdemo1.config;

public class MyLocalResolver {
}
