package com.zinc.blogdemo1.pojo;
import java.util.Date;
//员工表

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data

@NoArgsConstructor
public class Employee {


    private Integer id;
    private String lastName;
    private String email;
    private Integer gander;
    private Department department;
    private Date birth;

    public Employee(Integer id, String lastName, String email, Integer gander, Department department) {
        this.id = id;
        this.lastName = lastName;
        this.email = email;
        this.gander = gander;
        this.department = department;
        //默认的创建日期
        this.birth = new Date();
    }

}
